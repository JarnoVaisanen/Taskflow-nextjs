import type { Metadata } from 'next'
import './globals.css'

export const metadata: Metadata = {
  title: 'Taskflow — Advanced Todo App',
  description: 'A beautiful, feature-rich task manager built with Next.js',
}

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en" suppressHydrationWarning>
      <body className="grain">{children}</body>
    </html>
  )
}
