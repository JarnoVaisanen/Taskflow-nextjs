# Taskflow — Advanced Next.js Todo App

A production-ready, feature-rich task manager with a distinctive editorial aesthetic.

## Quick Start

```bash
npm install
npm run dev
```

Open [http://localhost:3000](http://localhost:3000) in your browser.

## Deploy to Vercel

```bash
npm install -g vercel
vercel --prod
```

Or connect your GitHub repo at [vercel.com](https://vercel.com) for auto-deploys.

---

## Features

### Core
- ✅ Add, edit (double-click), delete, complete tasks
- 📌 Pin important tasks to the top
- 🗄 Archive tasks out of the way
- 💾 Auto-saves to `localStorage` — data persists across sessions

### Task Details
- **4 priority levels**: Critical / High / Medium / Low
- **6 categories**: Personal, Work, Health, Learning, Finance, Creative
- **Due dates** with overdue/urgent indicators
- **Descriptions** for additional context
- **Subtasks** with progress bar per task

### Views & Filters
- **List view** — clean linear layout with drag-to-reorder
- **Board view** — Kanban columns by priority
- **Status filters**: All / Active / Completed
- **Category filters**: filter by any category
- **Full-text search** across title and description
- **Sort by**: Newest, Priority, Alphabetical, Due Date

### UX
- 🌙 Dark / Light mode toggle
- 📊 Stats bar: Total / Active / Done / Critical counts
- 📈 Progress bar with % completion
- Drag & drop reordering (list view)
- Overdue & urgent due date highlighting
- Hover actions (edit, pin, archive, delete)
- Smooth animations throughout

---

## Project Structure

```
taskflow/
├── app/
│   ├── layout.tsx       # Root layout with fonts
│   ├── page.tsx         # Entry point
│   └── globals.css      # Design tokens + custom CSS
├── components/
│   ├── TodoApp.tsx      # Main orchestrator
│   ├── Header.tsx       # Stats, progress, controls
│   ├── AddTodoForm.tsx  # Task creation form
│   ├── FilterBar.tsx    # Search, filters, sort
│   ├── TodoCard.tsx     # Individual task card
│   ├── BoardView.tsx    # Kanban board layout
│   └── EmptyState.tsx   # Empty state UI
├── lib/
│   ├── types.ts         # TypeScript interfaces
│   ├── constants.ts     # Priority/category config + sample data
│   ├── utils.ts         # Helpers (format, sort, etc.)
│   └── useTodos.ts      # Custom hook — all state logic
├── package.json
├── tailwind.config.ts
└── tsconfig.json
```

## Tech Stack

- **Next.js 14** (App Router)
- **TypeScript**
- **Tailwind CSS** (with custom design tokens via CSS variables)
- **localStorage** persistence
- Custom fonts: Syne (display) + Instrument Sans (body) + JetBrains Mono

## Design

Warm, editorial aesthetic inspired by analog notebooks — cream/charcoal palette in light mode, deep ink tones in dark mode, with amber accent color. Typography-led hierarchy using Syne for headings and Instrument Sans for body text.
