import { Todo, SortKey } from './types'
import { PRIORITY_CONFIG } from './constants'

export function formatDate(ts: number): string {
  const now = Date.now()
  const diff = now - ts
  if (diff < 60000) return 'just now'
  if (diff < 3600000) return `${Math.floor(diff / 60000)}m ago`
  if (diff < 86400000) return `${Math.floor(diff / 3600000)}h ago`
  if (diff < 604800000) return `${Math.floor(diff / 86400000)}d ago`
  return new Intl.DateTimeFormat('en-US', { month: 'short', day: 'numeric' }).format(new Date(ts))
}

export function formatDueDate(dateStr: string): { label: string; urgent: boolean; overdue: boolean } {
  if (!dateStr) return { label: '', urgent: false, overdue: false }
  const due = new Date(dateStr).getTime()
  const now = Date.now()
  const diff = due - now
  const overdue = diff < 0
  const urgent = diff > 0 && diff < 86400000 * 2

  if (overdue) {
    const days = Math.abs(Math.floor(diff / 86400000))
    return { label: days === 0 ? 'Due today' : `${days}d overdue`, urgent: false, overdue: true }
  }
  if (diff < 86400000) return { label: 'Due today', urgent: true, overdue: false }
  if (diff < 86400000 * 2) return { label: 'Due tomorrow', urgent: true, overdue: false }
  const days = Math.floor(diff / 86400000)
  return { label: `Due in ${days}d`, urgent: false, overdue: false }
}

export function sortTodos(todos: Todo[], sortBy: SortKey): Todo[] {
  return [...todos].sort((a, b) => {
    // Pinned always first
    if (a.pinned !== b.pinned) return b.pinned ? 1 : -1

    switch (sortBy) {
      case 'priority':
        return PRIORITY_CONFIG[a.priority].rank - PRIORITY_CONFIG[b.priority].rank
      case 'alpha':
        return a.text.localeCompare(b.text)
      case 'dueDate': {
        if (!a.dueDate && !b.dueDate) return b.createdAt - a.createdAt
        if (!a.dueDate) return 1
        if (!b.dueDate) return -1
        return new Date(a.dueDate).getTime() - new Date(b.dueDate).getTime()
      }
      default:
        return b.createdAt - a.createdAt
    }
  })
}

export function getCompletionPercent(todos: Todo[]): number {
  if (!todos.length) return 0
  return Math.round((todos.filter(t => t.completed).length / todos.length) * 100)
}

export function cn(...classes: (string | boolean | undefined | null)[]): string {
  return classes.filter(Boolean).join(' ')
}
