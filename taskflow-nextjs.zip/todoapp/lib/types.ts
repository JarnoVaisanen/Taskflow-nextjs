export type Priority = 'low' | 'medium' | 'high' | 'critical'
export type Category = 'personal' | 'work' | 'health' | 'learning' | 'finance' | 'creative'
export type ViewMode = 'list' | 'board' | 'timeline'
export type SortKey = 'created' | 'priority' | 'alpha' | 'dueDate'
export type FilterStatus = 'all' | 'active' | 'completed'

export interface Subtask {
  id: string
  text: string
  done: boolean
  createdAt: number
}

export interface Tag {
  id: string
  label: string
  color: string
}

export interface Todo {
  id: string
  text: string
  description: string
  completed: boolean
  priority: Priority
  category: Category
  createdAt: number
  updatedAt: number
  dueDate: string
  subtasks: Subtask[]
  tags: string[]
  pinned: boolean
  archived: boolean
  completedAt?: number
}

export interface AppState {
  todos: Todo[]
  tags: Tag[]
  filter: FilterStatus
  categoryFilter: string
  search: string
  sortBy: SortKey
  viewMode: ViewMode
  showArchived: boolean
  darkMode: boolean
}
