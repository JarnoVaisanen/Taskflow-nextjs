'use client'

import { useState, useCallback, useEffect } from 'react'
import { v4 as uuidv4 } from 'uuid'
import { Todo, Priority, Category, FilterStatus, SortKey, ViewMode } from '@/lib/types'
import { SAMPLE_TODOS } from '@/lib/constants'
import { sortTodos } from '@/lib/utils'

export function useTodos() {
  const [todos, setTodos] = useState<Todo[]>(SAMPLE_TODOS as Todo[])
  const [filter, setFilter] = useState<FilterStatus>('all')
  const [categoryFilter, setCategoryFilter] = useState<string>('all')
  const [search, setSearch] = useState('')
  const [sortBy, setSortBy] = useState<SortKey>('created')
  const [viewMode, setViewMode] = useState<ViewMode>('list')
  const [darkMode, setDarkMode] = useState(true)
  const [showArchived, setShowArchived] = useState(false)

  // Hydrate from localStorage
  useEffect(() => {
    try {
      const saved = localStorage.getItem('taskflow-todos')
      if (saved) setTodos(JSON.parse(saved))
      const dm = localStorage.getItem('taskflow-dark')
      if (dm !== null) setDarkMode(dm === 'true')
    } catch {}
  }, [])

  // Persist to localStorage
  useEffect(() => {
    try {
      localStorage.setItem('taskflow-todos', JSON.stringify(todos))
    } catch {}
  }, [todos])

  useEffect(() => {
    try {
      localStorage.setItem('taskflow-dark', String(darkMode))
    } catch {}
  }, [darkMode])

  const addTodo = useCallback((data: {
    text: string
    description: string
    priority: Priority
    category: Category
    dueDate: string
  }) => {
    const now = Date.now()
    const todo: Todo = {
      id: uuidv4(),
      text: data.text.trim(),
      description: data.description.trim(),
      completed: false,
      priority: data.priority,
      category: data.category,
      createdAt: now,
      updatedAt: now,
      dueDate: data.dueDate,
      subtasks: [],
      tags: [],
      pinned: false,
      archived: false,
    }
    setTodos(prev => [todo, ...prev])
    return todo
  }, [])

  const updateTodo = useCallback((id: string, updates: Partial<Todo>) => {
    setTodos(prev => prev.map(t =>
      t.id === id ? { ...t, ...updates, updatedAt: Date.now() } : t
    ))
  }, [])

  const toggleTodo = useCallback((id: string) => {
    setTodos(prev => prev.map(t =>
      t.id === id
        ? { ...t, completed: !t.completed, completedAt: !t.completed ? Date.now() : undefined, updatedAt: Date.now() }
        : t
    ))
  }, [])

  const deleteTodo = useCallback((id: string) => {
    setTodos(prev => prev.filter(t => t.id !== id))
  }, [])

  const pinTodo = useCallback((id: string) => {
    setTodos(prev => prev.map(t => t.id === id ? { ...t, pinned: !t.pinned } : t))
  }, [])

  const archiveTodo = useCallback((id: string) => {
    setTodos(prev => prev.map(t => t.id === id ? { ...t, archived: !t.archived } : t))
  }, [])

  const addSubtask = useCallback((todoId: string, text: string) => {
    const subtask = { id: uuidv4(), text: text.trim(), done: false, createdAt: Date.now() }
    setTodos(prev => prev.map(t =>
      t.id === todoId ? { ...t, subtasks: [...t.subtasks, subtask], updatedAt: Date.now() } : t
    ))
  }, [])

  const toggleSubtask = useCallback((todoId: string, subId: string) => {
    setTodos(prev => prev.map(t =>
      t.id === todoId
        ? { ...t, subtasks: t.subtasks.map(s => s.id === subId ? { ...s, done: !s.done } : s), updatedAt: Date.now() }
        : t
    ))
  }, [])

  const deleteSubtask = useCallback((todoId: string, subId: string) => {
    setTodos(prev => prev.map(t =>
      t.id === todoId
        ? { ...t, subtasks: t.subtasks.filter(s => s.id !== subId), updatedAt: Date.now() }
        : t
    ))
  }, [])

  const clearCompleted = useCallback(() => {
    setTodos(prev => prev.filter(t => !t.completed))
  }, [])

  const reorderTodos = useCallback((fromId: string, toId: string) => {
    setTodos(prev => {
      const arr = [...prev]
      const fromIdx = arr.findIndex(t => t.id === fromId)
      const toIdx = arr.findIndex(t => t.id === toId)
      if (fromIdx === -1 || toIdx === -1) return prev
      const [item] = arr.splice(fromIdx, 1)
      arr.splice(toIdx, 0, item)
      return arr
    })
  }, [])

  const filteredTodos = sortTodos(
    todos.filter(t => {
      if (!showArchived && t.archived) return false
      if (showArchived && !t.archived) return false
      if (filter === 'active' && t.completed) return false
      if (filter === 'completed' && !t.completed) return false
      if (categoryFilter !== 'all' && t.category !== categoryFilter) return false
      if (search && !t.text.toLowerCase().includes(search.toLowerCase()) &&
          !t.description.toLowerCase().includes(search.toLowerCase())) return false
      return true
    }),
    sortBy
  )

  const stats = {
    total: todos.filter(t => !t.archived).length,
    completed: todos.filter(t => t.completed && !t.archived).length,
    active: todos.filter(t => !t.completed && !t.archived).length,
    critical: todos.filter(t => t.priority === 'critical' && !t.completed && !t.archived).length,
    overdue: todos.filter(t => {
      if (!t.dueDate || t.completed || t.archived) return false
      return new Date(t.dueDate).getTime() < Date.now()
    }).length,
  }

  return {
    todos: filteredTodos,
    allTodos: todos,
    stats,
    filter, setFilter,
    categoryFilter, setCategoryFilter,
    search, setSearch,
    sortBy, setSortBy,
    viewMode, setViewMode,
    darkMode, setDarkMode,
    showArchived, setShowArchived,
    addTodo,
    updateTodo,
    toggleTodo,
    deleteTodo,
    pinTodo,
    archiveTodo,
    addSubtask,
    toggleSubtask,
    deleteSubtask,
    clearCompleted,
    reorderTodos,
  }
}
