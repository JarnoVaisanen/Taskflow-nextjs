import { Priority, Category } from './types'

export const PRIORITY_CONFIG: Record<Priority, {
  label: string
  color: string
  bg: string
  border: string
  darkBg: string
  darkBorder: string
  rank: number
}> = {
  critical: {
    label: 'Critical',
    color: '#ef4444',
    bg: '#fef2f2',
    border: '#fecaca',
    darkBg: '#2d0a0a',
    darkBorder: '#7f1d1d',
    rank: 0,
  },
  high: {
    label: 'High',
    color: '#f97316',
    bg: '#fff7ed',
    border: '#fed7aa',
    darkBg: '#2a1300',
    darkBorder: '#7c2d12',
    rank: 1,
  },
  medium: {
    label: 'Medium',
    color: '#eab308',
    bg: '#fefce8',
    border: '#fef08a',
    darkBg: '#1f1900',
    darkBorder: '#713f12',
    rank: 2,
  },
  low: {
    label: 'Low',
    color: '#22c55e',
    bg: '#f0fdf4',
    border: '#bbf7d0',
    darkBg: '#052e16',
    darkBorder: '#14532d',
    rank: 3,
  },
}

export const CATEGORY_CONFIG: Record<Category, {
  label: string
  icon: string
  color: string
}> = {
  personal:  { label: 'Personal',  icon: '🏠', color: '#8b5cf6' },
  work:      { label: 'Work',      icon: '💼', color: '#3b82f6' },
  health:    { label: 'Health',    icon: '💚', color: '#22c55e' },
  learning:  { label: 'Learning',  icon: '📚', color: '#f59e0b' },
  finance:   { label: 'Finance',   icon: '💰', color: '#10b981' },
  creative:  { label: 'Creative',  icon: '🎨', color: '#ec4899' },
}

export const SAMPLE_TODOS = [
  {
    id: 'sample-1',
    text: 'Design Q4 product roadmap',
    description: 'Coordinate with team leads and finalize priorities for the next quarter.',
    completed: false,
    priority: 'critical' as Priority,
    category: 'work' as Category,
    createdAt: Date.now() - 86400000 * 2,
    updatedAt: Date.now() - 3600000,
    dueDate: new Date(Date.now() + 86400000 * 3).toISOString().split('T')[0],
    subtasks: [
      { id: 'sub-1a', text: 'Engineering sync', done: true, createdAt: Date.now() - 80000000 },
      { id: 'sub-1b', text: 'Design review', done: false, createdAt: Date.now() - 70000000 },
      { id: 'sub-1c', text: 'Stakeholder sign-off', done: false, createdAt: Date.now() - 60000000 },
    ],
    tags: [],
    pinned: true,
    archived: false,
  },
  {
    id: 'sample-2',
    text: 'Morning workout routine',
    description: '45-minute session — mix of cardio and strength training.',
    completed: true,
    priority: 'medium' as Priority,
    category: 'health' as Category,
    createdAt: Date.now() - 86400000,
    updatedAt: Date.now() - 7200000,
    dueDate: '',
    subtasks: [
      { id: 'sub-2a', text: '20 min run', done: true, createdAt: Date.now() - 85000000 },
      { id: 'sub-2b', text: 'Core circuit', done: true, createdAt: Date.now() - 84000000 },
    ],
    tags: [],
    pinned: false,
    archived: false,
    completedAt: Date.now() - 3600000,
  },
  {
    id: 'sample-3',
    text: 'Read "Deep Work" chapters 3–5',
    description: '',
    completed: false,
    priority: 'low' as Priority,
    category: 'learning' as Category,
    createdAt: Date.now() - 43200000,
    updatedAt: Date.now() - 43200000,
    dueDate: '',
    subtasks: [],
    tags: [],
    pinned: false,
    archived: false,
  },
]
