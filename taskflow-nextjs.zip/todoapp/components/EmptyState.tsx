'use client'

interface EmptyStateProps {
  filter: string
  search: string
}

export default function EmptyState({ filter, search }: EmptyStateProps) {
  const messages = {
    search: { icon: '🔍', title: 'No results found', sub: `No tasks match "${search}"` },
    completed: { icon: '🎉', title: 'Nothing completed yet', sub: 'Check off some tasks to see them here' },
    active: { icon: '✨', title: 'All done!', sub: "You've completed everything. Nice work." },
    all: { icon: '📋', title: 'No tasks yet', sub: 'Add your first task to get started' },
  }

  const key = search ? 'search' : filter === 'completed' ? 'completed' : filter === 'active' ? 'active' : 'all'
  const msg = messages[key as keyof typeof messages]

  return (
    <div className="flex flex-col items-center justify-center py-20 text-center animate-fade-in">
      <div className="text-5xl mb-4">{msg.icon}</div>
      <div className="font-semibold text-lg mb-1" style={{ fontFamily: 'Syne, sans-serif', color: 'var(--text)' }}>
        {msg.title}
      </div>
      <div className="text-sm" style={{ color: 'var(--text3)', fontFamily: 'Instrument Sans' }}>
        {msg.sub}
      </div>
    </div>
  )
}
