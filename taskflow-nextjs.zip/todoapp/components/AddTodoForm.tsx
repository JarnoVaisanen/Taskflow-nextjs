'use client'

import { useState, useRef } from 'react'
import { Priority, Category } from '@/lib/types'
import { PRIORITY_CONFIG, CATEGORY_CONFIG } from '@/lib/constants'

interface AddTodoFormProps {
  onAdd: (data: { text: string; description: string; priority: Priority; category: Category; dueDate: string }) => void
}

export default function AddTodoForm({ onAdd }: AddTodoFormProps) {
  const [text, setText] = useState('')
  const [description, setDescription] = useState('')
  const [priority, setPriority] = useState<Priority>('medium')
  const [category, setCategory] = useState<Category>('personal')
  const [dueDate, setDueDate] = useState('')
  const [expanded, setExpanded] = useState(false)
  const [shake, setShake] = useState(false)
  const inputRef = useRef<HTMLInputElement>(null)

  const handleSubmit = () => {
    if (!text.trim()) {
      setShake(true)
      setTimeout(() => setShake(false), 500)
      inputRef.current?.focus()
      return
    }
    onAdd({ text, description, priority, category, dueDate })
    setText('')
    setDescription('')
    setDueDate('')
    setPriority('medium')
    setExpanded(false)
  }

  return (
    <div
      className="rounded-2xl p-4 mb-5 transition-all duration-200"
      style={{
        background: 'var(--surface)',
        border: `1.5px solid var(--border)`,
        boxShadow: '0 2px 20px rgba(0,0,0,0.06)',
        animation: shake ? 'shake 0.4s ease' : undefined,
      }}
    >
      {/* Main input */}
      <div className="flex items-center gap-3 mb-3">
        <div className="w-5 h-5 rounded-md flex-shrink-0" style={{ background: 'var(--border)', border: '2px solid var(--border2)' }} />
        <input
          ref={inputRef}
          value={text}
          onChange={e => { setText(e.target.value); if (!expanded && e.target.value) setExpanded(true) }}
          onKeyDown={e => {
            if (e.key === 'Enter' && !e.shiftKey) handleSubmit()
            if (e.key === 'Escape') { setText(''); setExpanded(false) }
          }}
          placeholder="What needs to be done?"
          className="task-input text-base"
          style={{ fontFamily: 'Syne, sans-serif', fontWeight: 600, fontSize: 16 }}
          autoComplete="off"
        />
        <button
          onClick={handleSubmit}
          className="flex-shrink-0 px-4 py-2 rounded-xl text-sm font-semibold transition-all duration-150"
          style={{
            background: 'var(--accent)',
            color: '#fff',
            fontFamily: 'Instrument Sans',
            boxShadow: '0 3px 12px rgba(212,113,30,0.35)',
          }}
          onMouseEnter={e => (e.currentTarget.style.transform = 'translateY(-1px)')}
          onMouseLeave={e => (e.currentTarget.style.transform = 'translateY(0)')}
        >
          + Add
        </button>
      </div>

      {/* Expanded options */}
      {expanded && (
        <div className="animate-fade-in">
          {/* Description */}
          <input
            value={description}
            onChange={e => setDescription(e.target.value)}
            placeholder="Add a description (optional)…"
            className="w-full text-sm mb-3 px-3 py-2 rounded-lg outline-none transition-colors"
            style={{
              background: 'var(--surface2)',
              border: '1px solid var(--border)',
              color: 'var(--text)',
              fontFamily: 'Instrument Sans',
              caretColor: 'var(--accent)',
            }}
          />

          {/* Controls row */}
          <div className="flex flex-wrap gap-2 items-center">
            {/* Priority */}
            <select
              value={priority}
              onChange={e => setPriority(e.target.value as Priority)}
              className="styled-select"
            >
              {(Object.keys(PRIORITY_CONFIG) as Priority[]).map(p => (
                <option key={p} value={p}>{PRIORITY_CONFIG[p].label}</option>
              ))}
            </select>

            {/* Category */}
            <select
              value={category}
              onChange={e => setCategory(e.target.value as Category)}
              className="styled-select"
            >
              {(Object.keys(CATEGORY_CONFIG) as Category[]).map(c => (
                <option key={c} value={c}>{CATEGORY_CONFIG[c].icon} {CATEGORY_CONFIG[c].label}</option>
              ))}
            </select>

            {/* Due date */}
            <input
              type="date"
              value={dueDate}
              onChange={e => setDueDate(e.target.value)}
              className="styled-select"
              style={{ colorScheme: 'dark' }}
              min={new Date().toISOString().split('T')[0]}
            />

            <button
              onClick={() => { setText(''); setDescription(''); setExpanded(false) }}
              className="ml-auto text-xs px-3 py-1.5 rounded-lg transition-colors"
              style={{ color: 'var(--text3)', fontFamily: 'Instrument Sans' }}
            >
              Cancel
            </button>
          </div>
        </div>
      )}
    </div>
  )
}
