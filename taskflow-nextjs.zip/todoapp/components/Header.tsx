'use client'

import { ViewMode, FilterStatus, SortKey } from '@/lib/types'

interface HeaderProps {
  stats: { total: number; completed: number; active: number; critical: number; overdue: number }
  darkMode: boolean
  setDarkMode: (v: boolean) => void
  viewMode: ViewMode
  setViewMode: (v: ViewMode) => void
  showArchived: boolean
  setShowArchived: (v: boolean) => void
  completionPct: number
}

export default function Header({
  stats, darkMode, setDarkMode, viewMode, setViewMode,
  showArchived, setShowArchived, completionPct
}: HeaderProps) {
  return (
    <header className="mb-8">
      {/* Top row */}
      <div className="flex items-start justify-between mb-6">
        <div>
          <h1 className="font-display text-4xl font-bold tracking-tight leading-none" style={{ color: 'var(--text)' }}>
            Task<span style={{ color: 'var(--accent)' }}>flow</span>
          </h1>
          <p className="text-sm mt-1" style={{ color: 'var(--text3)', fontFamily: 'Instrument Sans' }}>
            {stats.active} active · {stats.completed} done
            {stats.overdue > 0 && <span className="ml-2 font-semibold" style={{ color: '#ef4444' }}>⚑ {stats.overdue} overdue</span>}
          </p>
        </div>

        <div className="flex items-center gap-2">
          {/* View mode */}
          <div className="flex rounded-lg overflow-hidden" style={{ border: '1px solid var(--border)', background: 'var(--surface2)' }}>
            {(['list', 'board'] as ViewMode[]).map(mode => (
              <button
                key={mode}
                onClick={() => setViewMode(mode)}
                className="px-3 py-1.5 text-xs font-medium transition-colors"
                style={{
                  background: viewMode === mode ? 'var(--accent)' : 'transparent',
                  color: viewMode === mode ? '#fff' : 'var(--text3)',
                  fontFamily: 'Instrument Sans',
                }}
                data-tooltip={mode === 'list' ? 'List view' : 'Board view'}
              >
                {mode === 'list' ? '☰' : '⊞'}
              </button>
            ))}
          </div>

          {/* Archive toggle */}
          <button
            onClick={() => setShowArchived(v => !v)}
            className="px-3 py-1.5 text-xs rounded-lg transition-all"
            style={{
              background: showArchived ? 'var(--accent-dim)' : 'var(--surface2)',
              border: `1px solid ${showArchived ? 'var(--accent)' : 'var(--border)'}`,
              color: showArchived ? 'var(--accent)' : 'var(--text3)',
              fontFamily: 'Instrument Sans',
            }}
            data-tooltip="Toggle archive"
          >
            🗄 Archive
          </button>

          {/* Dark mode */}
          <button
            onClick={() => setDarkMode(!darkMode)}
            className="w-9 h-9 flex items-center justify-center rounded-lg transition-all"
            style={{ background: 'var(--surface2)', border: '1px solid var(--border)', fontSize: '16px' }}
            data-tooltip={darkMode ? 'Light mode' : 'Dark mode'}
          >
            {darkMode ? '☀️' : '🌙'}
          </button>
        </div>
      </div>

      {/* Stats bar */}
      <div className="grid grid-cols-4 gap-3 mb-5">
        {[
          { label: 'Total',    value: stats.total,     color: 'var(--accent)' },
          { label: 'Active',   value: stats.active,    color: '#60a5fa' },
          { label: 'Done',     value: stats.completed, color: '#4ade80' },
          { label: 'Critical', value: stats.critical,  color: '#ef4444' },
        ].map(s => (
          <div key={s.label} className="rounded-xl p-3 text-center" style={{ background: 'var(--surface)', border: '1px solid var(--border)' }}>
            <div className="text-2xl font-bold font-display tracking-tight" style={{ color: s.color }}>{s.value}</div>
            <div className="text-xs mt-0.5 uppercase tracking-wider" style={{ color: 'var(--text3)', fontFamily: 'Instrument Sans' }}>{s.label}</div>
          </div>
        ))}
      </div>

      {/* Progress bar */}
      <div className="relative">
        <div className="flex justify-between text-xs mb-1.5" style={{ color: 'var(--text3)', fontFamily: 'Instrument Sans' }}>
          <span>Overall progress</span>
          <span className="font-semibold" style={{ color: 'var(--accent)' }}>{completionPct}%</span>
        </div>
        <div className="h-2 rounded-full overflow-hidden" style={{ background: 'var(--border)' }}>
          <div
            className="progress-fill h-full rounded-full"
            style={{ width: `${completionPct}%`, background: 'linear-gradient(90deg, var(--accent), #f59e0b)' }}
          />
        </div>
      </div>
    </header>
  )
}
