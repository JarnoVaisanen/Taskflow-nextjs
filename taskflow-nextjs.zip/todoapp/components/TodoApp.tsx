'use client'

import { useEffect, useRef, useState } from 'react'
import { useTodos } from '@/lib/useTodos'
import { getCompletionPercent } from '@/lib/utils'
import Header from '@/components/Header'
import AddTodoForm from '@/components/AddTodoForm'
import FilterBar from '@/components/FilterBar'
import TodoCard from '@/components/TodoCard'
import BoardView from '@/components/BoardView'
import EmptyState from '@/components/EmptyState'

export default function TodoApp() {
  const {
    todos, allTodos, stats,
    filter, setFilter,
    categoryFilter, setCategoryFilter,
    search, setSearch,
    sortBy, setSortBy,
    viewMode, setViewMode,
    darkMode, setDarkMode,
    showArchived, setShowArchived,
    addTodo, updateTodo, toggleTodo, deleteTodo,
    pinTodo, archiveTodo, addSubtask, toggleSubtask,
    deleteSubtask, clearCompleted, reorderTodos,
  } = useTodos()

  // Apply dark mode class to html
  useEffect(() => {
    document.documentElement.classList.toggle('dark', darkMode)
  }, [darkMode])

  // Drag & drop state
  const dragFromId = useRef<string | null>(null)
  const dragToId = useRef<string | null>(null)

  const completedCount = allTodos.filter(t => t.completed && !t.archived).length
  const completionPct = getCompletionPercent(allTodos.filter(t => !t.archived))

  return (
    <div className="min-h-screen transition-colors duration-300" style={{ background: 'var(--bg)' }}>
      <div className="max-w-3xl mx-auto px-4 py-10 pb-24">
        <Header
          stats={stats}
          darkMode={darkMode}
          setDarkMode={setDarkMode}
          viewMode={viewMode}
          setViewMode={setViewMode}
          showArchived={showArchived}
          setShowArchived={setShowArchived}
          completionPct={completionPct}
        />

        {!showArchived && (
          <AddTodoForm onAdd={addTodo} />
        )}

        <FilterBar
          filter={filter}
          setFilter={setFilter}
          categoryFilter={categoryFilter}
          setCategoryFilter={setCategoryFilter}
          search={search}
          setSearch={setSearch}
          sortBy={sortBy}
          setSortBy={setSortBy}
          onClearCompleted={clearCompleted}
          completedCount={completedCount}
        />

        {/* Results count */}
        {(search || categoryFilter !== 'all') && todos.length > 0 && (
          <div className="text-xs mb-3" style={{ color: 'var(--text3)', fontFamily: 'Instrument Sans' }}>
            {todos.length} result{todos.length !== 1 ? 's' : ''}
            {search && ` for "${search}"`}
          </div>
        )}

        {/* Task list / board */}
        {todos.length === 0 ? (
          <EmptyState filter={filter} search={search} />
        ) : viewMode === 'board' ? (
          <BoardView
            todos={todos}
            onToggle={toggleTodo}
            onDelete={deleteTodo}
            onPin={pinTodo}
            onArchive={archiveTodo}
            onUpdate={updateTodo}
            onAddSubtask={addSubtask}
            onToggleSubtask={toggleSubtask}
            onDeleteSubtask={deleteSubtask}
          />
        ) : (
          <div className="space-y-2">
            {todos.map(todo => (
              <TodoCard
                key={todo.id}
                todo={todo}
                onToggle={toggleTodo}
                onDelete={deleteTodo}
                onPin={pinTodo}
                onArchive={archiveTodo}
                onUpdate={updateTodo}
                onAddSubtask={addSubtask}
                onToggleSubtask={toggleSubtask}
                onDeleteSubtask={deleteSubtask}
                onDragStart={id => { dragFromId.current = id }}
                onDragOver={id => { dragToId.current = id }}
                onDrop={() => {
                  if (dragFromId.current && dragToId.current && dragFromId.current !== dragToId.current) {
                    reorderTodos(dragFromId.current, dragToId.current)
                  }
                  dragFromId.current = null
                  dragToId.current = null
                }}
              />
            ))}
          </div>
        )}

        {/* Footer */}
        {allTodos.length > 0 && (
          <div
            className="fixed bottom-0 left-0 right-0 border-t px-4 py-3"
            style={{
              background: 'var(--bg)',
              borderColor: 'var(--border)',
              backdropFilter: 'blur(12px)',
            }}
          >
            <div className="max-w-3xl mx-auto flex items-center justify-between text-xs" style={{ color: 'var(--text3)', fontFamily: 'Instrument Sans' }}>
              <span>{stats.active} task{stats.active !== 1 ? 's' : ''} remaining</span>
              <span className="font-mono" style={{ fontFamily: 'JetBrains Mono', color: 'var(--accent)' }}>
                {completionPct}% complete
              </span>
              <span>Double-click to edit · Drag to reorder</span>
            </div>
          </div>
        )}
      </div>
    </div>
  )
}
