'use client'

import { FilterStatus, SortKey } from '@/lib/types'
import { CATEGORY_CONFIG } from '@/lib/constants'

interface FilterBarProps {
  filter: FilterStatus
  setFilter: (f: FilterStatus) => void
  categoryFilter: string
  setCategoryFilter: (c: string) => void
  search: string
  setSearch: (s: string) => void
  sortBy: SortKey
  setSortBy: (s: SortKey) => void
  onClearCompleted: () => void
  completedCount: number
}

export default function FilterBar({
  filter, setFilter,
  categoryFilter, setCategoryFilter,
  search, setSearch,
  sortBy, setSortBy,
  onClearCompleted, completedCount,
}: FilterBarProps) {
  return (
    <div className="mb-4 space-y-3">
      {/* Search */}
      <div className="relative">
        <span className="absolute left-3 top-1/2 -translate-y-1/2 text-sm" style={{ color: 'var(--text3)' }}>🔍</span>
        <input
          value={search}
          onChange={e => setSearch(e.target.value)}
          placeholder="Search tasks and descriptions…"
          className="w-full pl-9 pr-4 py-2.5 rounded-xl text-sm outline-none transition-colors"
          style={{
            background: 'var(--surface)',
            border: '1px solid var(--border)',
            color: 'var(--text)',
            fontFamily: 'Instrument Sans',
            caretColor: 'var(--accent)',
          }}
          onFocus={e => (e.target.style.borderColor = 'var(--accent)')}
          onBlur={e => (e.target.style.borderColor = 'var(--border)')}
        />
        {search && (
          <button
            onClick={() => setSearch('')}
            className="absolute right-3 top-1/2 -translate-y-1/2 text-xs rounded px-1"
            style={{ color: 'var(--text3)' }}
          >
            ✕
          </button>
        )}
      </div>

      {/* Filters row */}
      <div className="flex flex-wrap gap-2 items-center">
        {/* Status filters */}
        <div className="flex rounded-lg overflow-hidden" style={{ border: '1px solid var(--border)' }}>
          {(['all', 'active', 'completed'] as FilterStatus[]).map(f => (
            <button
              key={f}
              onClick={() => setFilter(f)}
              className="px-3 py-1.5 text-xs capitalize transition-colors"
              style={{
                background: filter === f ? 'var(--accent)' : 'var(--surface2)',
                color: filter === f ? '#fff' : 'var(--text3)',
                fontFamily: 'Instrument Sans',
                fontWeight: filter === f ? 600 : 400,
              }}
            >
              {f}
            </button>
          ))}
        </div>

        {/* Category filters */}
        <div className="flex gap-1 flex-wrap">
          <button
            onClick={() => setCategoryFilter('all')}
            className="px-2.5 py-1 rounded-full text-xs transition-all"
            style={{
              background: categoryFilter === 'all' ? 'var(--accent-dim)' : 'transparent',
              border: `1px solid ${categoryFilter === 'all' ? 'var(--accent)' : 'var(--border)'}`,
              color: categoryFilter === 'all' ? 'var(--accent)' : 'var(--text3)',
              fontFamily: 'Instrument Sans',
            }}
          >
            All
          </button>
          {(Object.entries(CATEGORY_CONFIG) as [string, { label: string; icon: string; color: string }][]).map(([key, cfg]) => (
            <button
              key={key}
              onClick={() => setCategoryFilter(categoryFilter === key ? 'all' : key)}
              className="px-2.5 py-1 rounded-full text-xs transition-all"
              style={{
                background: categoryFilter === key ? cfg.color + '22' : 'transparent',
                border: `1px solid ${categoryFilter === key ? cfg.color : 'var(--border)'}`,
                color: categoryFilter === key ? cfg.color : 'var(--text3)',
                fontFamily: 'Instrument Sans',
              }}
            >
              {cfg.icon} {cfg.label}
            </button>
          ))}
        </div>

        {/* Sort */}
        <div className="ml-auto flex items-center gap-2">
          <select
            value={sortBy}
            onChange={e => setSortBy(e.target.value as SortKey)}
            className="styled-select text-xs"
          >
            <option value="created">Newest first</option>
            <option value="priority">By priority</option>
            <option value="alpha">Alphabetical</option>
            <option value="dueDate">By due date</option>
          </select>

          {completedCount > 0 && (
            <button
              onClick={onClearCompleted}
              className="text-xs px-3 py-1.5 rounded-lg transition-colors"
              style={{
                color: '#ef4444',
                border: '1px solid #ef444430',
                background: '#ef444410',
                fontFamily: 'Instrument Sans',
              }}
              onMouseEnter={e => (e.currentTarget.style.background = '#ef444422')}
              onMouseLeave={e => (e.currentTarget.style.background = '#ef444410')}
            >
              Clear done ({completedCount})
            </button>
          )}
        </div>
      </div>
    </div>
  )
}
