'use client'

import { useState, useRef } from 'react'
import { Todo } from '@/lib/types'
import { PRIORITY_CONFIG, CATEGORY_CONFIG } from '@/lib/constants'
import { formatDate, formatDueDate } from '@/lib/utils'

interface TodoCardProps {
  todo: Todo
  onToggle: (id: string) => void
  onDelete: (id: string) => void
  onPin: (id: string) => void
  onArchive: (id: string) => void
  onUpdate: (id: string, data: Partial<Todo>) => void
  onAddSubtask: (todoId: string, text: string) => void
  onToggleSubtask: (todoId: string, subId: string) => void
  onDeleteSubtask: (todoId: string, subId: string) => void
  onDragStart?: (id: string) => void
  onDragOver?: (id: string) => void
  onDrop?: () => void
}

export default function TodoCard({
  todo, onToggle, onDelete, onPin, onArchive, onUpdate,
  onAddSubtask, onToggleSubtask, onDeleteSubtask,
  onDragStart, onDragOver, onDrop,
}: TodoCardProps) {
  const [expanded, setExpanded] = useState(false)
  const [editing, setEditing] = useState(false)
  const [editText, setEditText] = useState(todo.text)
  const [editDesc, setEditDesc] = useState(todo.description)
  const [subtaskInput, setSubtaskInput] = useState('')
  const [isDragOver, setIsDragOver] = useState(false)
  const editRef = useRef<HTMLInputElement>(null)

  const pCfg = PRIORITY_CONFIG[todo.priority]
  const cCfg = CATEGORY_CONFIG[todo.category]
  const due = formatDueDate(todo.dueDate)
  const subDone = todo.subtasks.filter(s => s.done).length
  const subPct = todo.subtasks.length ? (subDone / todo.subtasks.length) * 100 : 0

  const saveEdit = () => {
    if (!editText.trim()) return
    onUpdate(todo.id, { text: editText.trim(), description: editDesc.trim() })
    setEditing(false)
  }

  return (
    <div
      draggable
      onDragStart={() => onDragStart?.(todo.id)}
      onDragOver={e => { e.preventDefault(); setIsDragOver(true); onDragOver?.(todo.id) }}
      onDragLeave={() => setIsDragOver(false)}
      onDrop={() => { setIsDragOver(false); onDrop?.() }}
      className="rounded-2xl transition-all duration-200 animate-slide-in group"
      style={{
        background: 'var(--surface)',
        border: `1.5px solid ${todo.pinned ? pCfg.color + '55' : isDragOver ? 'var(--accent)' : 'var(--border)'}`,
        opacity: todo.completed ? 0.6 : 1,
        boxShadow: todo.pinned ? `0 0 0 1px ${pCfg.color}22, 0 2px 16px ${pCfg.color}12` : 'none',
        cursor: 'grab',
      }}
    >
      {/* Priority stripe */}
      <div className="h-0.5 rounded-t-2xl" style={{ background: pCfg.color, opacity: todo.completed ? 0.3 : 0.8 }} />

      <div className="p-4">
        {/* Main row */}
        <div className="flex items-start gap-3">
          {/* Checkbox */}
          <input
            type="checkbox"
            checked={todo.completed}
            onChange={() => onToggle(todo.id)}
            className="custom-check mt-0.5"
          />

          {/* Content */}
          <div className="flex-1 min-w-0">
            {editing ? (
              <div>
                <input
                  ref={editRef}
                  autoFocus
                  value={editText}
                  onChange={e => setEditText(e.target.value)}
                  onKeyDown={e => {
                    if (e.key === 'Enter') saveEdit()
                    if (e.key === 'Escape') setEditing(false)
                  }}
                  className="task-input text-sm font-semibold w-full mb-2"
                  style={{ fontSize: 15 }}
                />
                <input
                  value={editDesc}
                  onChange={e => setEditDesc(e.target.value)}
                  placeholder="Description…"
                  onKeyDown={e => e.key === 'Enter' && saveEdit()}
                  className="w-full text-xs px-2 py-1.5 rounded-lg outline-none"
                  style={{
                    background: 'var(--surface2)',
                    border: '1px solid var(--border)',
                    color: 'var(--text)',
                    fontFamily: 'Instrument Sans',
                    caretColor: 'var(--accent)',
                  }}
                />
                <div className="flex gap-2 mt-2">
                  <button onClick={saveEdit} className="text-xs px-3 py-1 rounded-lg" style={{ background: 'var(--accent)', color: '#fff', fontFamily: 'Instrument Sans' }}>Save</button>
                  <button onClick={() => setEditing(false)} className="text-xs px-3 py-1 rounded-lg" style={{ color: 'var(--text3)', fontFamily: 'Instrument Sans', border: '1px solid var(--border)' }}>Cancel</button>
                </div>
              </div>
            ) : (
              <>
                <div className="flex items-start gap-2 flex-wrap">
                  {todo.pinned && <span className="text-xs" title="Pinned">📌</span>}
                  <span
                    className="font-semibold text-sm leading-snug cursor-pointer hover:opacity-80 transition-opacity"
                    style={{
                      fontFamily: 'Syne, sans-serif',
                      color: 'var(--text)',
                      textDecoration: todo.completed ? 'line-through' : 'none',
                      opacity: todo.completed ? 0.6 : 1,
                    }}
                    onDoubleClick={() => { setEditing(true); setEditText(todo.text) }}
                  >
                    {todo.text}
                  </span>
                </div>
                {todo.description && (
                  <p className="text-xs mt-1 line-clamp-2" style={{ color: 'var(--text3)', fontFamily: 'Instrument Sans' }}>
                    {todo.description}
                  </p>
                )}
              </>
            )}

            {/* Tags row */}
            {!editing && (
              <div className="flex flex-wrap items-center gap-1.5 mt-2">
                {/* Priority badge */}
                <span
                  className="text-xs px-2 py-0.5 rounded-full font-semibold"
                  style={{
                    background: pCfg.color + '20',
                    color: pCfg.color,
                    border: `1px solid ${pCfg.color}40`,
                    fontFamily: 'Instrument Sans',
                  }}
                >
                  {pCfg.label}
                </span>

                {/* Category badge */}
                <span
                  className="text-xs px-2 py-0.5 rounded-full"
                  style={{
                    background: cCfg.color + '18',
                    color: cCfg.color,
                    border: `1px solid ${cCfg.color}35`,
                    fontFamily: 'Instrument Sans',
                  }}
                >
                  {cCfg.icon} {cCfg.label}
                </span>

                {/* Due date */}
                {due.label && (
                  <span
                    className="text-xs px-2 py-0.5 rounded-full"
                    style={{
                      background: due.overdue ? '#ef444420' : due.urgent ? '#f9731620' : 'var(--surface2)',
                      color: due.overdue ? '#ef4444' : due.urgent ? '#f97316' : 'var(--text3)',
                      border: `1px solid ${due.overdue ? '#ef444440' : due.urgent ? '#f9731640' : 'var(--border)'}`,
                      fontFamily: 'Instrument Sans',
                    }}
                  >
                    📅 {due.label}
                  </span>
                )}

                {/* Subtask count */}
                {todo.subtasks.length > 0 && (
                  <span className="text-xs" style={{ color: 'var(--text3)', fontFamily: 'JetBrains Mono' }}>
                    {subDone}/{todo.subtasks.length}
                  </span>
                )}

                {/* Created */}
                <span className="text-xs ml-auto" style={{ color: 'var(--text3)', fontFamily: 'Instrument Sans' }}>
                  {formatDate(todo.createdAt)}
                </span>
              </div>
            )}

            {/* Subtask progress bar */}
            {todo.subtasks.length > 0 && !editing && (
              <div className="mt-2 h-1 rounded-full overflow-hidden" style={{ background: 'var(--border)' }}>
                <div
                  className="h-full rounded-full progress-fill"
                  style={{ width: `${subPct}%`, background: '#4ade80' }}
                />
              </div>
            )}
          </div>

          {/* Action buttons */}
          <div className="flex items-center gap-0.5 opacity-0 group-hover:opacity-100 transition-opacity flex-shrink-0">
            <button onClick={() => setExpanded(v => !v)} className="p-1.5 rounded-lg transition-colors" style={{ color: 'var(--text3)' }}
              onMouseEnter={e => (e.currentTarget.style.background = 'var(--surface2)')}
              onMouseLeave={e => (e.currentTarget.style.background = 'transparent')}
              data-tooltip={expanded ? 'Collapse' : 'Expand'}
            >
              {expanded ? '▲' : '▼'}
            </button>
            <button onClick={() => { setEditing(true); setEditText(todo.text) }} className="p-1.5 rounded-lg transition-colors" style={{ color: 'var(--text3)' }}
              onMouseEnter={e => (e.currentTarget.style.background = 'var(--surface2)')}
              onMouseLeave={e => (e.currentTarget.style.background = 'transparent')}
              data-tooltip="Edit"
            >
              ✏️
            </button>
            <button onClick={() => onPin(todo.id)} className="p-1.5 rounded-lg transition-colors" style={{ color: todo.pinned ? 'var(--accent)' : 'var(--text3)' }}
              onMouseEnter={e => (e.currentTarget.style.background = 'var(--surface2)')}
              onMouseLeave={e => (e.currentTarget.style.background = 'transparent')}
              data-tooltip={todo.pinned ? 'Unpin' : 'Pin'}
            >
              📌
            </button>
            <button onClick={() => onArchive(todo.id)} className="p-1.5 rounded-lg transition-colors" style={{ color: 'var(--text3)' }}
              onMouseEnter={e => (e.currentTarget.style.background = 'var(--surface2)')}
              onMouseLeave={e => (e.currentTarget.style.background = 'transparent')}
              data-tooltip="Archive"
            >
              🗄
            </button>
            <button onClick={() => onDelete(todo.id)} className="p-1.5 rounded-lg transition-colors" style={{ color: '#ef4444' }}
              onMouseEnter={e => (e.currentTarget.style.background = '#ef444415')}
              onMouseLeave={e => (e.currentTarget.style.background = 'transparent')}
              data-tooltip="Delete"
            >
              ✕
            </button>
          </div>
        </div>

        {/* Expanded section */}
        {expanded && (
          <div className="mt-3 pt-3 animate-fade-in" style={{ borderTop: '1px solid var(--border)' }}>
            {/* Subtasks */}
            <div className="space-y-1.5">
              {todo.subtasks.map(sub => (
                <div key={sub.id} className="flex items-center gap-2 group/sub">
                  <input
                    type="checkbox"
                    checked={sub.done}
                    onChange={() => onToggleSubtask(todo.id, sub.id)}
                    className="custom-check"
                    style={{ width: 16, height: 16 }}
                  />
                  <span
                    className="flex-1 text-sm"
                    style={{
                      color: sub.done ? 'var(--text3)' : 'var(--text)',
                      textDecoration: sub.done ? 'line-through' : 'none',
                      fontFamily: 'Instrument Sans',
                    }}
                  >
                    {sub.text}
                  </span>
                  <button
                    onClick={() => onDeleteSubtask(todo.id, sub.id)}
                    className="text-xs opacity-0 group-hover/sub:opacity-100 transition-opacity"
                    style={{ color: '#ef4444' }}
                  >
                    ✕
                  </button>
                </div>
              ))}
            </div>

            {/* Add subtask */}
            <div className="flex gap-2 mt-2">
              <input
                value={subtaskInput}
                onChange={e => setSubtaskInput(e.target.value)}
                onKeyDown={e => {
                  if (e.key === 'Enter' && subtaskInput.trim()) {
                    onAddSubtask(todo.id, subtaskInput)
                    setSubtaskInput('')
                  }
                }}
                placeholder="Add subtask… (Enter)"
                className="flex-1 text-xs px-3 py-1.5 rounded-lg outline-none"
                style={{
                  background: 'var(--surface2)',
                  border: '1px solid var(--border)',
                  color: 'var(--text)',
                  fontFamily: 'Instrument Sans',
                  caretColor: 'var(--accent)',
                }}
                onFocus={e => (e.target.style.borderColor = 'var(--accent)')}
                onBlur={e => (e.target.style.borderColor = 'var(--border)')}
              />
              <button
                onClick={() => { if (subtaskInput.trim()) { onAddSubtask(todo.id, subtaskInput); setSubtaskInput('') } }}
                className="text-xs px-3 py-1.5 rounded-lg"
                style={{ background: 'var(--accent)', color: '#fff', fontFamily: 'Instrument Sans' }}
              >
                +
              </button>
            </div>

            {/* Meta footer */}
            <div className="flex items-center gap-3 mt-3 text-xs" style={{ color: 'var(--text3)', fontFamily: 'Instrument Sans' }}>
              <span>Created {formatDate(todo.createdAt)}</span>
              {todo.updatedAt !== todo.createdAt && <span>· Updated {formatDate(todo.updatedAt)}</span>}
              {todo.completedAt && <span>· Completed {formatDate(todo.completedAt)}</span>}
            </div>
          </div>
        )}
      </div>
    </div>
  )
}
