'use client'

import { Todo } from '@/lib/types'
import { PRIORITY_CONFIG, CATEGORY_CONFIG } from '@/lib/constants'
import { formatDueDate } from '@/lib/utils'
import TodoCard from './TodoCard'

interface BoardViewProps {
  todos: Todo[]
  onToggle: (id: string) => void
  onDelete: (id: string) => void
  onPin: (id: string) => void
  onArchive: (id: string) => void
  onUpdate: (id: string, data: Partial<Todo>) => void
  onAddSubtask: (todoId: string, text: string) => void
  onToggleSubtask: (todoId: string, subId: string) => void
  onDeleteSubtask: (todoId: string, subId: string) => void
}

const COLUMNS = [
  { key: 'critical', label: '🔴 Critical', color: '#ef4444' },
  { key: 'high',     label: '🟠 High',     color: '#f97316' },
  { key: 'medium',   label: '🟡 Medium',   color: '#eab308' },
  { key: 'low',      label: '🟢 Low',      color: '#22c55e' },
]

export default function BoardView({ todos, ...handlers }: BoardViewProps) {
  return (
    <div className="flex gap-4 overflow-x-auto pb-4">
      {COLUMNS.map(col => {
        const colTodos = todos.filter(t => t.priority === col.key)
        return (
          <div key={col.key} className="board-col flex-shrink-0">
            <div
              className="flex items-center justify-between px-3 py-2 rounded-xl mb-3"
              style={{ background: col.color + '15', border: `1px solid ${col.color}30` }}
            >
              <span className="text-sm font-semibold" style={{ color: col.color, fontFamily: 'Syne, sans-serif' }}>
                {col.label}
              </span>
              <span
                className="text-xs px-2 py-0.5 rounded-full"
                style={{ background: col.color + '25', color: col.color, fontFamily: 'JetBrains Mono' }}
              >
                {colTodos.length}
              </span>
            </div>
            <div className="space-y-3">
              {colTodos.length === 0 ? (
                <div
                  className="rounded-xl p-6 text-center text-xs"
                  style={{ border: `1px dashed var(--border)`, color: 'var(--text3)', fontFamily: 'Instrument Sans' }}
                >
                  No tasks
                </div>
              ) : (
                colTodos.map(todo => (
                  <TodoCard key={todo.id} todo={todo} {...handlers} />
                ))
              )}
            </div>
          </div>
        )
      })}
    </div>
  )
}
